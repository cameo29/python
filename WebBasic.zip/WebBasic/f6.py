'''
Created on 2017. 11. 7.
@author: edu
Flask url뒤에 /붙이면
/pro  => /pro/
/pro/ => /pro/

'''
# 모듈 가져오기
from flask import Flask
# 플라스크 객체 생성
app = Flask(__name__)

# /pro => /pro/ => OK
# /pro/ => OK
@app.route('/pro/')
def pro():
    return "pro page"

# /home  => ok
# /home/ => 404
@app.route('/home')
def home():
    return "home page"

# 홈페이지는 예외적으로 움직임
# 127.0.0.1:5000 => OK
# 127.0.0.1:5000/ => OK
@app.route('/')
def home1():
    return "home1 page"


# 서버 가동
if __name__ == '__main__':
    # 직접 pyhton fl.py 구동했을 경우 
    # 서버 가동
    app.run()
else:
    print("본 모듈은 단독으로 구동될때 정상 작동합니다.")    
'''
Created on 2017. 11. 7.
@author: edu
Flask : 디버깅모드 구동하기 => 개발할때만 사용, 서비스시에는 제거!!
      : 디버깅 모드에서는 코드를 수정 저장하면 자동 리로드가 된다
'''
# 모듈 가져오기
from flask import Flask
# 플라스크 객체 생성
app = Flask(__name__)

@app.route('/')
def home():
    return "home page 한글"

# 서버 가동
if __name__ == '__main__':
    # 직접 pyhton fl.py 구동했을 경우 
    # 서버 가동
    # app.run(debug=True)
    # or
    app.debug = True
    app.run()
else:
    print("본 모듈은 단독으로 구동될때 정상 작동합니다.")    
    
    
    
    
    
    
    
    
    
    
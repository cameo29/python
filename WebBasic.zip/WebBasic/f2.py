'''
Created on 2017. 11. 7.
@author: edu
Flask 
'''
# 모듈 가져오기
from flask import Flask
# 플라스크 객체 생성
app = Flask(__name__)






# 서버 가동
if __name__ == '__main__':
    # 직접 pyhton fl.py 구동했을 경우 
    # 서버 가동
    app.run()
else:
    print("본 모듈은 단독으로 구동될때 정상 작동합니다.")    
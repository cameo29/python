'''
Created on 2017. 11. 7.
@author: edu
Flask : 라우팅 응용 => 동적 파라미터
'''
# 모듈 가져오기
from flask import Flask
# 플라스크 객체 생성
app = Flask(__name__)

# 동적 파라미터 데이터는 함수의 인자값으로 전달됨
@app.route('/userInfo/<uid>')
def userInfo(uid):
    return "hello userinfo : userid is %s" % uid

# 동적 파라미터에 타입을 지정 (int, float, path)
@app.route('/login/<int:sid>')
def login(sid):
    return "user sid is %d" % sid

# 동적 파라미터 구성
# 기본 url /math
# 동적 파라미터 1 : x1 (int)
# 동적 파라미터 2 : y1 (float)
# 동적 파라미터 3 : type (ex)json)
# 이렇게 구성된 라우팅을 구현하시오. (응답 결과는 자유롭게 값을 다 찍는 수준으로)
@app.route('/math/<int:x1>/<float:y1>/<type>')
def math(x1, y1, type):
    return "%d %2.2f %s" % (x1, y1, type)



# 서버 가동
if __name__ == '__main__':
    # 직접 pyhton fl.py 구동했을 경우 
    # 서버 가동
    app.run()
else:
    print("본 모듈은 단독으로 구동될때 정상 작동합니다.")    
'''
데이터베이스 접속 및 해제
mysql 계열 제품 사용(marria DB)
pymysql 모듈 사용
'''
# import 컨벤션 (이름이 길어서 별칭으로 처리)
# imoprt pandas as pd
import pymysql as my

# 디비 오픈
conn = my.connect(
            host='localhost',
            user='root',
            password='1234',
            db='python',
            charset='utf8')

# 데이터 가져오기
# 커서 획득
cursor = conn.cursor()
# 쿼리 수행
sql    = "SELECT * FROM USERS ORDER BY regdate DESC;"
cursor.execute( sql )
# 결과 획득
rows   = cursor.fetchall()
#print( rows )
# 이름만 출력하시오
for row in rows:
    print( row[3] )

# 디비 연결 종료
conn.close()
















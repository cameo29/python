/**
 * main.html의 메인 스크립트 
 */
// 문서(document => DOM)가 메로리에 로드되면 호출 
// window.onload=function(){}
$(document).ready(function(){
	// alert('hi');
	// submit.이벤트 를 잡아서 ajax로 통신 요청
	// form element object = $('#search')
	// 사용자가 전송 버튼을 클릭하면 등록된 콜백함수가 호출됨
	console.log( $('#search').serialize() );
	$('#search').on('submit', function(evt){
		evt.preventDefault();
		// 서버 통신
		$.ajax({
			url:'/search',
			type:'post',
			dataType:'json',
			data:$('#search').serialize(),
			success:function(team){
				//console.log( team );
				// 기존의 검색 결과를 삭제
				$('#result').empty();
					
				var html = "";
				html += "<tr>";
				html += "    <th><strong>"+ team.id +"</strong></th>";
				html += "    <td class=\"tm\">";
				html += "        <div>";
				html += "        <span id=\"team_HT\">"+ team.name +"</span>";
				html += "        </div>";
				html += "    </td>";
				html += "    <td><span>"+ team.play +"</span></td>";
				html += "    <td><span>"+ team.w +"</span></td>";
				html += "    <td><span>"+ team.l +"</span></td>";
				html += "    <td><span>"+ team.d +"</span></td>";
				html += "    <td><strong>"+ team.win +"8</strong></td>";
				html += "    <td><span>"+ team.etc1 +"</span></td>";
				html += "    <td><span>"+ team.etc2 +"</span></td>";
				html += "    <td><span>"+ team.etc3 +"0</span></td>";
				html += "    <td><span>"+ team.etc4 +"</span></td>";
				html += "    <td class=\"last\"><span>"+ team.etc5 +"</span></td>";
				html += "</tr>";
				// 검색 결과 추가
				$('#result').append( html );
				
				// 검색창 초기화
				$('input[name=keyword]').val("");
				
				
			},
			error:function(err){
				console.log( "에러", err );
			}
		});
		return false;
	});
});












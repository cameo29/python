'''
Created on 2017. 11. 7.
@author: edu
Flask 
/       홈페이지 (로그인 링크)
-----------------------------------------------------------------
/login  로그인 폼(GET), 로그인 처리(POST)
/main   메인 페이지 (특정 정보 출력 (DB에서 가져오기)) GET
/search 메인 페이지 위에 검색창의 검색 (POST) -> JSON 응답  <-> ajax 통신(js)
-----------------------------------------------------------------
/newsRegi  글등록 (제목, 내용, 첨부파일), GET, POST
/news      뉴스리스트
/news/<id> 특정글 GET
-----------------------------------------------------------------
'''
# 모듈 가져오기
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, json
import pymysql as my

# 플라스크 객체 생성
app = Flask(__name__)

# /
@app.route('/')
def home():
    return render_template("home.html")
    
# /login
@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'GET':
        return render_template("login.html")
    else:
        # post로 전달된 데이터 받기
        # print( request.form )
        if loginDataVaild(request.form['uid'],request.form['upw']):    
            rows = loginDBProc(request.form['uid'],request.form['upw'])
            if rows:
                # 쿠키 저장 처리
                # 세션 저장 처리
                session["uid"] = request.form['uid']            
                #return "post login %s %s" % (request.form['uid'], request.form['upw'])
                # 페이지 이동                
                return redirect( url_for('main') )
            else:
                return "<script>alert('로그인실패.');history.back();</script>"
        else:
            return "<script>alert('정확하게 입력후 다시 로그인하세요.');history.back();</script>"

# /main
@app.route('/main')
def main():
    # 데이터 가져오기 rows 획득
    rows = getBaseballInfo()
    return render_template("main.html",data=rows)

# /search

@app.route('/search', methods=['POST'])
def search():
    # 파리미터 획득
    keyword = request.form['keyword']    
    # 쿼리
    rows    = getSearchBaseball( keyword )
    # 결과 반환 => json
    return jsonify( **rows[0] )

# /logout

@app.route('/logout')
def logout():
    # 세션 제거
    session.pop('uid', None)
    return "<script>alert('로그아웃 되었습니다.');document.location.href='/';</script>"
    # 페이지 이동
    #return redirect( url_for('home') )

# 파일 업로드
@app.route('/upload', methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        # input 태그에서 타입이 img_file인 요소의 name 속성값을 넣어서 파일 객체 획득
        f = request.files['img_file']
        f.save('C:\\Users\\edu\\eclipse-workspace\\WebBasic\\uploads\\' + f.filename )
        return "file upload complete!!"
    else:
        return render_template("upload.html")

# 뉴스 목록 보기
@app.route('/news', methods=["GET", "POST"]  )
@app.route('/news/<id>')
def news(id=None):
    if request.method == "POST":
        rows = selectNews()
        # [ {},{},... ]
        return jsonify( rows ) # json.dump(rows) )
    else:
        if id :
            rows = selectNews(id)
            print( rows )
            return render_template("newsView.html", data = rows)
        else:
            return render_template("news.html")

# 새글 입력 및 등록
@app.route('/newsRegi', methods=["GET", "POST"])
def newsRegi():
    # 세션 체크 하여서, 세션이 없으면 로그인으로 이동
    if not 'uid' in session:
        return redirect( url_for('login') )
    # 세션이 존재하면 내용 진행
    if request.method == "POST":
        # title, content
        title   = request.form['title']
        content = request.form['content']
        author  = session["uid"]
        # input 태그에서 타입이 img_file인 요소의 name 속성값을 넣어서 파일 객체 획득        
        f       = request.files['img_file']
        f.save('C:\\Users\\edu\\eclipse-workspace\\WebBasic\\static\\uploads\\' + f.filename )
        
        if insertNews(title, content, author, "/static/uploads/"+f.filename):
            return "<script>alert('등록되었습니다.');document.location.href='"+url_for('news')+"';</script>"
        else:
            return "<script>alert('등록실패.');history.back();</script>"
        
        #return "file upload complete!! %s %s %s %s" % (title, content, author, "uploads/"+f.filename)
    else:
        return render_template("newRegi.html")

# 새글 입력 쿼리
def insertNews( title, content, author, path  ):
    conn = my.connect(
            host='localhost',
            user='root',
            password='1234',
            db='python',
            charset='utf8'
            # 커서 타입을 직접 지정 가능(연결시)
            # , cursorclass=pymysql.cursors.DictCursor
            )
    isSuccess = False
    try:
        with conn.cursor() as cursor:
            # Create a new record
            sql = "INSERT INTO `bbs` (`title`, `content`, `author`, `path`) VALUES (%s, %s, %s, %s)"
            cursor.execute(sql, (title, content, author, path))
            
        conn.commit()
        isSuccess = True
    except Exception as e:
        print( e )
    finally:        
        conn.close()
        return isSuccess

# 로그인 입력값 체크
def loginDataVaild(uid, upw):
    return uid and upw


# 로그인 디비 처리 => 성공 여부를 돌려준다
def loginDBProc(uid, upw):
    conn = my.connect(
            host='localhost',
            user='root',
            password='1234',
            db='python',
            charset='utf8'
            # 커서 타입을 직접 지정 가능(연결시)
            # , cursorclass=pymysql.cursors.DictCursor
            )
    cursor = conn.cursor( my.cursors.DictCursor )
    sql    = "SELECT * FROM USERS WHERE uid=%s and upw=%s;"
    cursor.execute( sql, (uid, upw) )
    rows   = cursor.fetchall()
    conn.close()
    return rows

# 뉴스 목록 가져오기
def selectNews(id=None):
    conn = my.connect(
            host='localhost',
            user='root',
            password='1234',
            db='python',
            charset='utf8'
            # 커서 타입을 직접 지정 가능(연결시)
            # , cursorclass=pymysql.cursors.DictCursor
            )
    cursor = conn.cursor( my.cursors.DictCursor )
    if id:
        sql    = "SELECT * FROM bbs where id=%s order by id desc;"
        cursor.execute( sql, id  )
    else:
        sql    = "SELECT * FROM bbs order by id desc limit 0, 100;"
        cursor.execute( sql  )
    rows   = cursor.fetchall()
    conn.close()
    return rows

# 보안키
app.secret_key = 'ldhisaxlklkkw0181'

# 야구팀 순위 정보등 가져오기 
def getBaseballInfo():
    conn = my.connect(
            host='localhost',
            user='root',
            password='1234',
            db='python',
            charset='utf8'
            # 커서 타입을 직접 지정 가능(연결시)
            # , cursorclass=pymysql.cursors.DictCursor
            )
    cursor = conn.cursor( my.cursors.DictCursor )
    sql    = "SELECT * FROM baseball"
    cursor.execute( sql )
    rows   = cursor.fetchall()
    conn.close()
    return rows

# 야구팀 검색
def getSearchBaseball( keyword ):
    conn = my.connect(
            host='localhost',
            user='root',
            password='1234',
            db='python',
            charset='utf8'
            # 커서 타입을 직접 지정 가능(연결시)
            # , cursorclass=pymysql.cursors.DictCursor
            )
    cursor = conn.cursor( my.cursors.DictCursor )
    sql    = "SELECT * FROM baseball where name=%s"
    cursor.execute( sql, keyword )
    rows   = cursor.fetchall()
    conn.close()
    return rows

# 서버 가동

if __name__ == '__main__':
    # 직접 pyhton fl.py 구동했을 경우 
    # 서버 가동
    app.run(debug=True)
else:
    print("본 모듈은 단독으로 구동될때 정상 작동합니다.") 
    
    
    
    
    
    
       
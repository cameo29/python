import pymysql as my

class DBHelper:
    conn = None
    def __init__(self):
        self.create()
    def create(self):
        self.conn = my.connect(
            host='localhost',
            user='root',
            password='1234',
            db='python',
            charset='utf8'
            # 커서 타입을 직접 지정 가능(연결시)
            # , cursorclass=pymysql.cursors.DictCursor
            )
    def destory(self):
        self.conn.close()        
    # 야구팀 순위 정보등 가져오기 
    def getBaseballInfo(self):
        cursor = self.conn.cursor( my.cursors.DictCursor )
        sql    = "SELECT * FROM baseball"
        cursor.execute( sql )
        rows   = cursor.fetchall()
        return rows

    # 야구팀 검색
    def getSearchBaseball( self, keyword ):
        cursor = self.conn.cursor( my.cursors.DictCursor )
        sql    = "SELECT * FROM baseball where name=%s"
        cursor.execute( sql, keyword )
        rows   = cursor.fetchall()
        return rows
    
    # 로그인 디비 처리 => 성공 여부를 돌려준다
    def loginDBProc(self,uid, upw):
        cursor = self.conn.cursor( my.cursors.DictCursor )
        sql    = "SELECT * FROM USERS WHERE uid=%s and upw=%s;"
        cursor.execute( sql, (uid, upw) )
        rows   = cursor.fetchall()
        return rows

    # 뉴스 목록 가져오기
    def selectNews(self, id=None):
        cursor = self.conn.cursor( my.cursors.DictCursor )
        if id:
            sql    = "SELECT * FROM bbs where id=%s order by id desc;"
            cursor.execute( sql, id  )
        else:
            sql    = "SELECT * FROM bbs order by id desc limit 0, 100;"
            cursor.execute( sql  )
        rows   = cursor.fetchall()
        return rows
    def selectNewsEx(self, id=None, sp=0, w=100):
        print( "selectNewsEx", sp, w)
        cursor = self.conn.cursor( my.cursors.DictCursor )
        if id:
            sql    = "SELECT * FROM bbs where id=%s order by id desc;"
            cursor.execute( sql, id  )
        else:
            sql    = "SELECT * FROM bbs order by id desc limit "+sp+", "+w+";"
            cursor.execute( sql)
        rows   = cursor.fetchall()
        print( rows, sp, w)
        return rows
    
    # 새글 입력 쿼리
    def insertNews( self, title, content, author, path  ):
        isSuccess = False
        try:
            with self.conn.cursor() as cursor:
                # Create a new record
                sql = "INSERT INTO `bbs` (`title`, `content`, `author`, `path`) VALUES (%s, %s, %s, %s)"
                cursor.execute(sql, (title, content, author, path))
                
            self.conn.commit()
            isSuccess = True
        except Exception as e:
            print( e )
        finally:        
            return isSuccess
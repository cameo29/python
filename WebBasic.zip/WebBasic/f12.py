'''
Created on 2017. 11. 7.
@author: edu
Flask 쿠키, get 파라미터
'''
# 모듈 가져오기
from flask import Flask, render_template, make_response, request
# 플라스크 객체 생성
app = Flask(__name__)

@app.route('/')
def home():
    # get 파라미터 획득
    # http://127.0.0.1:5000/?sp=0&w=100
    startPage = request.args.get('sp', '')
    weight    = request.args.get('w', '')
    # 쿠키
    cook      = request.cookies.get('cook')
    if cook:
        return "home page %s sp=%s w=%s" % (cook, startPage, weight)
    else:
        return "home page sp=%s w=%s" % (startPage, weight)

@app.route('/makeCook/<cook>')
def makeCook(cook=None):
    if cook:
        # 쿠키생성
        print(cook)  
        # make_response => 응답 헤더, 쿠키 등을 수정 응답!!
        res = make_response( render_template('cook.html') )
        res.set_cookie("cook", cook)
        return res
    else:
        render_template('cook.html')


# 서버 가동
if __name__ == '__main__':
    # 직접 pyhton fl.py 구동했을 경우 
    # 서버 가동
    app.run()
else:
    print("본 모듈은 단독으로 구동될때 정상 작동합니다.")   
    
    
    
    
    
    
     
'''
데이터베이스 접속 및 해제
mysql 계열 제품 사용(marria DB)
pymysql 모듈 사용
딕셔너리로 데이터 받아오기
'''
# import 컨벤션 (이름이 길어서 별칭으로 처리)
# imoprt pandas as pd
import pymysql as my

# 디비 오픈
conn = my.connect(
            host='localhost',
            user='root',
            password='1234',
            db='python',
            charset='utf8'
            # 커서 타입을 직접 지정 가능(연결시)
            # , cursorclass=pymysql.cursors.DictCursor
            )

# 로그인 쿼리 수행
# 커서 획득
cursor = conn.cursor( my.cursors.DictCursor )
# 쿼리 수행
# 파라미터는 %s로 받고, 문자열을 의미한는 것은 아님
sql    = "SELECT * FROM USERS WHERE uid=%s and upw=%s;"
# 파라미터는 튜플 구조로 순서대로 삽입
cursor.execute( sql, ('nia2','1234') )
# 결과 획득
rows   = cursor.fetchall()
print( rows )
# 아이디, 이름만 출력하시오
for row in rows:
    print( row['uid'], row['name'] )

# 디비 연결 종료
conn.close()
















'''
Created on 2017. 11. 7.
@author: edu
Flask html을 렌더링 하여 처리 => 템플릿 엔진 => jinja2(신사)를 사용
flask에 내장되어 있음
render_template : 렌더링 담당
{% ..... %} 문장 블럭
{{ ....  }} 값을 출력 
{# ....  #} 주석 
'''
# 모듈 가져오기
from flask import Flask, render_template
from distutils.log import debug
# 플라스크 객체 생성
app = Flask(__name__)

# 2개의 라우팅을 하나의 함수에 적용
# 파라미터 없을 경우에 대비해 함수 인자 초기값 처리
# index.html 파일은 templates 밑에 있어야 함
@app.route('/main/')
@app.route('/main/<uid>')
def main(uid=None):
    return render_template('index.html', uid=uid)



# 서버 가동
if __name__ == '__main__':
    # 직접 pyhton fl.py 구동했을 경우 
    # 서버 가동
    app.run(debug=True)
else:
    print("본 모듈은 단독으로 구동될때 정상 작동합니다.")    
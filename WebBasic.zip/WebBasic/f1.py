'''
Created on 2017. 11. 7.
@author: edu
Flask 기본 구동 확인
WSGI CGI의 일정
WSGI 종류
 - nginx, apache 같은 server-often high-profile 웹서버
 - pyhton, nodejs 같은 스크립트로 짜여진 web app
pyhton의 플라스크, 장고 같은 프레임원은 WSGI 지원하는 모듈임 
개발속도 높고, 유연한 구성
'''
# 모듈 가져오기
from flask import Flask
# 플라스크 객체 생성
# 모듈로 구동할때와, 직접 구동할때 설정되는 이름이 다름 : __name__
# __name__이 직접 구동될때의 이름 __main__ 일 경우에만 서버 정상 가동
app = Flask(__name__)

# 라우팅
@app.route("/")
def home():
    return "hello Flask"

# 서버 가동
if __name__ == '__main__':
    # 직접 pyhton fl.py 구동했을 경우 
    # 서버 가동
    app.run()
else:
    print("본 모듈은 단독으로 구동될때 정상 작동합니다.")
    

